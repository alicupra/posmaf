using POS.Core.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace POS.Core.Interfaces
{
    public interface ISaleService
    {
        Task<Sale?> CreateSaleAsync(Sale sale);
        Task<Sale?> GetSaleByIdAsync(int id);
        Task<IEnumerable<Sale>?> GetAllSalesAsync();
        Task<IEnumerable<Sale>?> GetSalesByDateRangeAsync(DateTime startDate, DateTime endDate);
        Task<bool> DeleteSaleAsync(int id);
        Task<Sale?> UpdateSaleAsync(Sale sale);
    }
}