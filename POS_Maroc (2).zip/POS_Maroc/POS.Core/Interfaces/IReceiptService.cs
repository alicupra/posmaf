using POS.Core.Models;
using System.Threading.Tasks;

namespace POS.Core.Interfaces
{
    public interface IReceiptService
    {
        Task GenerateReceiptAsync(Sale sale);
        Task PrintReceiptAsync(Sale sale);
        byte[]? GetReceiptPdfAsync(int saleId);
    }
}