using System;

namespace POS.Core.Models
{
    public class SaleItem
    {
        public int Id { get; set; }
        public int SaleId { get; set; }
        public int ProductId { get; set; }
        public decimal Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal Discount { get; set; }
        public decimal TaxRate { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal Subtotal { get; set; }
        public DateTime CreatedAt { get; set; }
        
        // Navigation properties
        public virtual Sale? Sale { get; set; }
        public virtual Product? Product { get; set; }
    }
}