using System;
using System.Collections.Generic;

namespace POS.Core.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string? Barcode { get; set; }
        public string? Name { get; set; }
        public string? Description { get; set; }
        public decimal Cost { get; set; }
        public decimal Price { get; set; }
        public decimal StockQuantity { get; set; }
        public bool IsActive { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        
        // Foreign keys
        public int? TaxId { get; set; }
        public Tax? Tax { get; set; }
        
        public int? CategoryId { get; set; }
        public Category? Category { get; set; }
        
        // Related entities
        public ICollection<SaleItem>? SaleItems { get; set; }
    }
}