using System;
using System.Collections.Generic;

namespace POS.Core.Models
{
    public class Sale
    {
        public int Id { get; set; }
        public string? Reference { get; set; }
        public DateTime SaleDate { get; set; }
        
        // Foreign keys
        public int? UserId { get; set; }
        public User? User { get; set; }
        
        public int? CustomerId { get; set; }
        public Customer? Customer { get; set; }
        
        // Financial details
        public decimal Subtotal { get; set; }
        public decimal TaxAmount { get; set; }
        public decimal DiscountAmount { get; set; }
        public decimal Total { get; set; }
        public decimal AmountPaid { get; set; }
        public decimal Change { get; set; }
        
        // Payment details
        public int? PaymentMethodId { get; set; }
        public PaymentMethod? PaymentMethod { get; set; }
        
        // Related entities
        public ICollection<SaleItem>? Items { get; set; }
        
        // Tracking fields
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public bool IsCancelled { get; set; }
        public string? CancellationReason { get; set; }
    }
}