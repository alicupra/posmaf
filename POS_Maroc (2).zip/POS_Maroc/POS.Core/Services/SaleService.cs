using POS.Core.Interfaces;
using POS.Core.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace POS.Core.Services
{
    public class SaleService : ISaleService
    {
        private readonly IRepository<Sale> _saleRepository;
        private readonly IRepository<SaleItem> _saleItemRepository;
        private readonly IReceiptService _receiptService;

        public SaleService(
            IRepository<Sale> saleRepository,
            IRepository<SaleItem> saleItemRepository,
            IReceiptService receiptService)
        {
            _saleRepository = saleRepository;
            _saleItemRepository = saleItemRepository;
            _receiptService = receiptService;
        }

        public async Task<Sale?> CreateSaleAsync(Sale sale)
        {
            sale.CreatedAt = DateTime.Now;
            
            // Calculate sale totals and tax
            decimal subtotal = 0;
            decimal taxAmount = 0;
            
            if (sale.Items != null)
            {
                foreach (var item in sale.Items)
                {
                    item.Subtotal = item.Quantity * item.UnitPrice * (1 - item.Discount / 100);
                    item.TaxAmount = item.Subtotal * (item.TaxRate / 100);
                    
                    subtotal += item.Subtotal;
                    taxAmount += item.TaxAmount;
                    
                    item.CreatedAt = DateTime.Now;
                }
            }
            
            sale.Subtotal = subtotal;
            sale.TaxAmount = taxAmount;
            sale.Total = subtotal + taxAmount;
            
            await _saleRepository.AddAsync(sale);
            await _saleRepository.SaveChangesAsync();
            
            // Generate receipt
            await _receiptService.GenerateReceiptAsync(sale);
            
            return sale;
        }

        public async Task<bool> DeleteSaleAsync(int id)
        {
            await _saleRepository.DeleteByIdAsync(id);
            await _saleRepository.SaveChangesAsync();
            return true;
        }

        public async Task<IEnumerable<Sale>?> GetAllSalesAsync()
        {
            return await _saleRepository.GetAllAsync();
        }

        public async Task<Sale?> GetSaleByIdAsync(int id)
        {
            return await _saleRepository.GetByIdAsync(id);
        }

        public async Task<IEnumerable<Sale>?> GetSalesByDateRangeAsync(DateTime startDate, DateTime endDate)
        {
            return await _saleRepository.FindAsync(s => s.CreatedAt >= startDate && s.CreatedAt <= endDate);
        }

        public async Task<Sale?> UpdateSaleAsync(Sale sale)
        {
            sale.UpdatedAt = DateTime.Now;
            
            await _saleRepository.UpdateAsync(sale);
            await _saleRepository.SaveChangesAsync();
            
            return sale;
        }
    }
}